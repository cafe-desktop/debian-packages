/* ctkshortcutswindow.h
 *
 * Copyright (C) 2015 Christian Hergert <christian@hergert.me>
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public License as
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __CTK_SHORTCUTS_WINDOW_H__
#define __CTK_SHORTCUTS_WINDOW_H__

#include <ctk/ctkwindow.h>

G_BEGIN_DECLS

#define CTK_TYPE_SHORTCUTS_WINDOW            (ctk_shortcuts_window_get_type ())
#define CTK_SHORTCUTS_WINDOW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), CTK_TYPE_SHORTCUTS_WINDOW, CtkShortcutsWindow))
#define CTK_SHORTCUTS_WINDOW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), CTK_TYPE_SHORTCUTS_WINDOW, CtkShortcutsWindowClass))
#define CTK_IS_SHORTCUTS_WINDOW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CTK_TYPE_SHORTCUTS_WINDOW))
#define CTK_IS_SHORTCUTS_WINDOW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), CTK_TYPE_SHORTCUTS_WINDOW))
#define CTK_SHORTCUTS_WINDOW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), CTK_TYPE_SHORTCUTS_WINDOW, CtkShortcutsWindowClass))


typedef struct _CtkShortcutsWindow         CtkShortcutsWindow;
typedef struct _CtkShortcutsWindowClass    CtkShortcutsWindowClass;


struct _CtkShortcutsWindow
{
  CtkWindow window;
};

struct _CtkShortcutsWindowClass
{
  CtkWindowClass parent_class;

  void (*close)  (CtkShortcutsWindow *self);
  void (*search) (CtkShortcutsWindow *self);
};

CDK_AVAILABLE_IN_3_20
GType ctk_shortcuts_window_get_type (void) G_GNUC_CONST;

G_DEFINE_AUTOPTR_CLEANUP_FUNC(CtkShortcutsWindow, g_object_unref)

G_END_DECLS

#endif /* CTK_SHORTCUTS_WINDOW _H */

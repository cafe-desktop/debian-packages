/*
 * bean-version.h
 * This file is part of libbean
 *
 * libbean is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * libbean is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA.
 */

#ifndef __BEAN_VERSION_H__
#define __BEAN_VERSION_H__

/**
 * SECTION:bean-version
 * @short_description: Bean version checking
 *
 * Bean provides macros to check the version of the library at compile-time
 */

/**
 * BEAN_MAJOR_VERSION:
 *
 * Bean major version component (e.g. 1 if %BEAN_VERSION is 1.2.3)
 */
#define BEAN_MAJOR_VERSION              (2)

/**
 * BEAN_MINOR_VERSION:
 *
 * Bean minor version component (e.g. 2 if %BEAN_VERSION is 1.2.3)
 */
#define BEAN_MINOR_VERSION              (2)

/**
 * BEAN_MICRO_VERSION:
 *
 * Bean micro version component (e.g. 3 if %BEAN_VERSION is 1.2.3)
 */
#define BEAN_MICRO_VERSION              (0)

/**
 * BEAN_VERSION
 *
 * Bean version.
 */
#define BEAN_VERSION                    (2.2.0)

/**
 * BEAN_VERSION_S:
 *
 * Bean version, encoded as a string, useful for printing and
 * concatenation.
 */
#define BEAN_VERSION_S                  "2.2.0"

#define BEAN_ENCODE_VERSION(major,minor,micro) \
        ((major) << 24 | (minor) << 16 | (micro) << 8)

/**
 * BEAN_VERSION_HEX:
 *
 * Bean version, encoded as an hexadecimal number, useful for
 * integer comparisons.
 */
#define BEAN_VERSION_HEX \
        (BEAN_ENCODE_VERSION (BEAN_MAJOR_VERSION, BEAN_MINOR_VERSION, BEAN_MICRO_VERSION))

/**
 * BEAN_CHECK_VERSION:
 * @major: required major version
 * @minor: required minor version
 * @micro: required micro version
 *
 * Compile-time version checking. Evaluates to %TRUE if the version
 * of bean is greater than the required one.
 */
#define BEAN_CHECK_VERSION(major,minor,micro)   \
        (BEAN_MAJOR_VERSION > (major) || \
         (BEAN_MAJOR_VERSION == (major) && BEAN_MINOR_VERSION > (minor)) || \
         (BEAN_MAJOR_VERSION == (major) && BEAN_MINOR_VERSION == (minor) && \
          BEAN_MICRO_VERSION >= (micro)))

#endif /* __BEAN_VERSION_H__ */

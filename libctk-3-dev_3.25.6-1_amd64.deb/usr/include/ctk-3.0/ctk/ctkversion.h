/* CTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Modified by the CTK+ Team and others 1997-1999.  See the AUTHORS
 * file for a list of people on the CTK+ Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * CTK+ at ftp://ftp.ctk.org/pub/ctk/.
 */

#if !defined (__CTK_H_INSIDE__) && !defined (CTK_COMPILATION)
#error "Only <ctk/ctk.h> can be included directly."
#endif

#ifndef __CTK_VERSION_H__
#define __CTK_VERSION_H__

/**
 * SECTION:ctkfeatures
 * @Short_description: Variables and functions to check the CTK+ version
 * @Title: Version Information
 *
 * CTK+ provides version information, primarily useful in configure checks
 * for builds that have a configure script. Applications will not typically
 * use the features described here.
 */

/**
 * CTK_MAJOR_VERSION:
 *
 * Like ctk_get_major_version(), but from the headers used at
 * application compile time, rather than from the library linked
 * against at application run time.
 */
#define CTK_MAJOR_VERSION (3)

/**
 * CTK_MINOR_VERSION:
 *
 * Like ctk_get_minor_version(), but from the headers used at
 * application compile time, rather than from the library linked
 * against at application run time.
 */
#define CTK_MINOR_VERSION (25)

/**
 * CTK_MICRO_VERSION:
 *
 * Like ctk_get_micro_version(), but from the headers used at
 * application compile time, rather than from the library linked
 * against at application run time.
 */
#define CTK_MICRO_VERSION (6)

/**
 * CTK_BINARY_AGE:
 *
 * Like ctk_get_binary_age(), but from the headers used at
 * application compile time, rather than from the library linked
 * against at application run time.
 */
#define CTK_BINARY_AGE    (2506)

/**
 * CTK_INTERFACE_AGE:
 *
 * Like ctk_get_interface_age(), but from the headers used at
 * application compile time, rather than from the library linked
 * against at application run time.
 */
#define CTK_INTERFACE_AGE (4)

/**
 * CTK_CHECK_VERSION:
 * @major: major version (e.g. 1 for version 1.2.5)
 * @minor: minor version (e.g. 2 for version 1.2.5)
 * @micro: micro version (e.g. 5 for version 1.2.5)
 *
 * Returns %TRUE if the version of the CTK+ header files
 * is the same as or newer than the passed-in version.
 *
 * Returns: %TRUE if CTK+ headers are new enough
 */
#define CTK_CHECK_VERSION(major,minor,micro)                          \
    (CTK_MAJOR_VERSION > (major) ||                                   \
     (CTK_MAJOR_VERSION == (major) && CTK_MINOR_VERSION > (minor)) || \
     (CTK_MAJOR_VERSION == (major) && CTK_MINOR_VERSION == (minor) && \
      CTK_MICRO_VERSION >= (micro)))

#endif /* __CTK_VERSION_H__ */

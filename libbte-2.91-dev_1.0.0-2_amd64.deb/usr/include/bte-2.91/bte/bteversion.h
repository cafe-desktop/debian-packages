/*
 * Copyright © 2008 Christian Persch
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef __BTE_BTE_VERSION_H__
#define __BTE_BTE_VERSION_H__

#if !defined (__BTE_BTE_H_INSIDE__) && !defined (BTE_COMPILATION)
#error "Only <bte/bte.h> can be included directly."
#endif

#include <glib.h>

#include "btemacros.h"

G_BEGIN_DECLS

/**
 * SECTION:bte-version
 * @short_description: Library version checks
 *
 * These macros enable compile time checks of the library version.
 */

/**
 * BTE_MAJOR_VERSION:
 *
 * The major version number of the BTE library
 * (e.g. in version 3.1.4 this is 3).
 */
#define BTE_MAJOR_VERSION (1)

/**
 * BTE_MINOR_VERSION:
 *
 * The minor version number of the BTE library
 * (e.g. in version 3.1.4 this is 1).
 */
#define BTE_MINOR_VERSION (0)

/**
 * BTE_MICRO_VERSION:
 *
 * The micro version number of the BTE library
 * (e.g. in version 3.1.4 this is 4).
 */
#define BTE_MICRO_VERSION (0)

/**
 * BTE_CHECK_VERSION:
 * @major: required major version
 * @minor: required minor version
 * @micro: required micro version
 *
 * Macro to check the library version at compile time.
 * It returns %1 if the version of BTE is greater or
 * equal to the required one, and %0 otherwise.
 */
#define BTE_CHECK_VERSION(major,minor,micro) \
  (BTE_MAJOR_VERSION > (major) || \
   (BTE_MAJOR_VERSION == (major) && BTE_MINOR_VERSION > (minor)) || \
   (BTE_MAJOR_VERSION == (major) && BTE_MINOR_VERSION == (minor) && BTE_MICRO_VERSION >= (micro)))

_BTE_PUBLIC
guint bte_get_major_version (void) _BTE_CXX_NOEXCEPT G_GNUC_CONST;

_BTE_PUBLIC
guint bte_get_minor_version (void) _BTE_CXX_NOEXCEPT G_GNUC_CONST;

_BTE_PUBLIC
guint bte_get_micro_version (void) _BTE_CXX_NOEXCEPT G_GNUC_CONST;

G_END_DECLS

#endif /* __BTE_BTE_VERSION_H__ */

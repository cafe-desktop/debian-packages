/* cdkversionmacros.h - version boundaries checks
 * Copyright (C) 2012 Red Hat, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.▸ See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */

#if !defined (__CDK_H_INSIDE__) && !defined (CDK_COMPILATION)
#error "Only <cdk/cdk.h> can be included directly."
#endif

#ifndef __CDK_VERSION_MACROS_H__
#define __CDK_VERSION_MACROS_H__

#include <glib.h>

#define CDK_MAJOR_VERSION (3)
#define CDK_MINOR_VERSION (25)
#define CDK_MICRO_VERSION (5)

#ifndef _CDK_EXTERN
#define _CDK_EXTERN extern
#endif

/**
 * CDK_DISABLE_DEPRECATION_WARNINGS:
 *
 * A macro that should be defined before including the cdk.h header.
 * If it is defined, no compiler warnings will be produced for uses
 * of deprecated CDK and CTK+ APIs.
 */

#ifdef CDK_DISABLE_DEPRECATION_WARNINGS
#define CDK_DEPRECATED _CDK_EXTERN
#define CDK_DEPRECATED_FOR(f) _CDK_EXTERN
#define CDK_UNAVAILABLE(maj,min) _CDK_EXTERN
#else
#define CDK_DEPRECATED G_DEPRECATED _CDK_EXTERN
#define CDK_DEPRECATED_FOR(f) G_DEPRECATED_FOR(f) _CDK_EXTERN
#define CDK_UNAVAILABLE(maj,min) G_UNAVAILABLE(maj,min) _CDK_EXTERN
#endif

/* XXX: Every new stable minor release bump should add a macro here */

/**
 * CDK_VERSION_3_0:
 *
 * A macro that evaluates to the 3.0 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.4
 */
#define CDK_VERSION_3_0         (G_ENCODE_VERSION (3, 0))

/**
 * CDK_VERSION_3_2:
 *
 * A macro that evaluates to the 3.2 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.4
 */
#define CDK_VERSION_3_2         (G_ENCODE_VERSION (3, 2))

/**
 * CDK_VERSION_3_4:
 *
 * A macro that evaluates to the 3.4 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.4
 */
#define CDK_VERSION_3_4         (G_ENCODE_VERSION (3, 4))

/**
 * CDK_VERSION_3_6:
 *
 * A macro that evaluates to the 3.6 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.6
 */
#define CDK_VERSION_3_6         (G_ENCODE_VERSION (3, 6))

/**
 * CDK_VERSION_3_8:
 *
 * A macro that evaluates to the 3.8 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.8
 */
#define CDK_VERSION_3_8         (G_ENCODE_VERSION (3, 8))

/**
 * CDK_VERSION_3_10:
 *
 * A macro that evaluates to the 3.10 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.10
 */
#define CDK_VERSION_3_10        (G_ENCODE_VERSION (3, 10))

/**
 * CDK_VERSION_3_12:
 *
 * A macro that evaluates to the 3.12 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.12
 */
#define CDK_VERSION_3_12        (G_ENCODE_VERSION (3, 12))

/**
 * CDK_VERSION_3_14:
 *
 * A macro that evaluates to the 3.14 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.14
 */
#define CDK_VERSION_3_14        (G_ENCODE_VERSION (3, 14))

/**
 * CDK_VERSION_3_16:
 *
 * A macro that evaluates to the 3.16 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.16
 */
#define CDK_VERSION_3_16        (G_ENCODE_VERSION (3, 16))

/**
 * CDK_VERSION_3_18:
 *
 * A macro that evaluates to the 3.18 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.18
 */
#define CDK_VERSION_3_18        (G_ENCODE_VERSION (3, 18))

/**
 * CDK_VERSION_3_20:
 *
 * A macro that evaluates to the 3.20 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.18
 */
#define CDK_VERSION_3_20        (G_ENCODE_VERSION (3, 20))

/**
 * CDK_VERSION_3_22:
 *
 * A macro that evaluates to the 3.22 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.20
 */
#define CDK_VERSION_3_22        (G_ENCODE_VERSION (3, 22))

/**
 * CDK_VERSION_3_24:
 *
 * A macro that evaluates to the 3.24 version of CDK, in a format
 * that can be used by the C pre-processor.
 *
 * Since: 3.24
 */
#define CDK_VERSION_3_24        (G_ENCODE_VERSION (3, 24))

/* evaluates to the current stable version; for development cycles,
 * this means the next stable target
 */
#if (CDK_MINOR_VERSION % 2)
#define CDK_VERSION_CUR_STABLE         (G_ENCODE_VERSION (CDK_MAJOR_VERSION, CDK_MINOR_VERSION + 1))
#else
#define CDK_VERSION_CUR_STABLE         (G_ENCODE_VERSION (CDK_MAJOR_VERSION, CDK_MINOR_VERSION))
#endif

/* evaluates to the previous stable version */
#if (CDK_MINOR_VERSION % 2)
#define CDK_VERSION_PREV_STABLE        (G_ENCODE_VERSION (CDK_MAJOR_VERSION, CDK_MINOR_VERSION - 1))
#else
#define CDK_VERSION_PREV_STABLE        (G_ENCODE_VERSION (CDK_MAJOR_VERSION, CDK_MINOR_VERSION - 2))
#endif

/**
 * CDK_VERSION_MIN_REQUIRED:
 *
 * A macro that should be defined by the user prior to including
 * the cdk.h header.
 * The definition should be one of the predefined CDK version
 * macros: %CDK_VERSION_3_0, %CDK_VERSION_3_2,...
 *
 * This macro defines the lower bound for the CDK API to use.
 *
 * If a function has been deprecated in a newer version of CDK,
 * it is possible to use this symbol to avoid the compiler warnings
 * without disabling warning for every deprecated function.
 *
 * Since: 3.4
 */
#ifndef CDK_VERSION_MIN_REQUIRED
# define CDK_VERSION_MIN_REQUIRED      (CDK_VERSION_CUR_STABLE)
#endif

/**
 * CDK_VERSION_MAX_ALLOWED:
 *
 * A macro that should be defined by the user prior to including
 * the cdk.h header.
 * The definition should be one of the predefined CDK version
 * macros: %CDK_VERSION_3_0, %CDK_VERSION_3_2,...
 *
 * This macro defines the upper bound for the CDK API to use.
 *
 * If a function has been introduced in a newer version of CDK,
 * it is possible to use this symbol to get compiler warnings when
 * trying to use that function.
 *
 * Since: 3.4
 */
#ifndef CDK_VERSION_MAX_ALLOWED
# if CDK_VERSION_MIN_REQUIRED > CDK_VERSION_PREV_STABLE
#  define CDK_VERSION_MAX_ALLOWED      CDK_VERSION_MIN_REQUIRED
# else
#  define CDK_VERSION_MAX_ALLOWED      CDK_VERSION_CUR_STABLE
# endif
#endif

/* sanity checks */
#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_MIN_REQUIRED
#error "CDK_VERSION_MAX_ALLOWED must be >= CDK_VERSION_MIN_REQUIRED"
#endif
#if CDK_VERSION_MIN_REQUIRED < CDK_VERSION_3_0
#error "CDK_VERSION_MIN_REQUIRED must be >= CDK_VERSION_3_0"
#endif

#define CDK_AVAILABLE_IN_ALL                  _CDK_EXTERN

/* XXX: Every new stable minor release should add a set of macros here */

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_0
# define CDK_DEPRECATED_IN_3_0                CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_0_FOR(f)         CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_0                _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_0_FOR(f)         _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_0
# define CDK_AVAILABLE_IN_3_0                 CDK_UNAVAILABLE(3, 0)
#else
# define CDK_AVAILABLE_IN_3_0                 _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_2
# define CDK_DEPRECATED_IN_3_2                CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_2_FOR(f)         CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_2                _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_2_FOR(f)         _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_2
# define CDK_AVAILABLE_IN_3_2                 CDK_UNAVAILABLE(3, 2)
#else
# define CDK_AVAILABLE_IN_3_2                 _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_4
# define CDK_DEPRECATED_IN_3_4                CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_4_FOR(f)         CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_4                _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_4_FOR(f)         _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_4
# define CDK_AVAILABLE_IN_3_4                 CDK_UNAVAILABLE(3, 4)
#else
# define CDK_AVAILABLE_IN_3_4                 _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_6
# define CDK_DEPRECATED_IN_3_6                CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_6_FOR(f)         CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_6                _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_6_FOR(f)         _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_6
# define CDK_AVAILABLE_IN_3_6                 CDK_UNAVAILABLE(3, 6)
#else
# define CDK_AVAILABLE_IN_3_6                 _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_8
# define CDK_DEPRECATED_IN_3_8                CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_8_FOR(f)         CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_8                _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_8_FOR(f)         _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_8
# define CDK_AVAILABLE_IN_3_8                 CDK_UNAVAILABLE(3, 8)
#else
# define CDK_AVAILABLE_IN_3_8                 _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_10
# define CDK_DEPRECATED_IN_3_10               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_10_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_10               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_10_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_10
# define CDK_AVAILABLE_IN_3_10                CDK_UNAVAILABLE(3, 10)
#else
# define CDK_AVAILABLE_IN_3_10                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_12
# define CDK_DEPRECATED_IN_3_12               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_12_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_12               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_12_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_12
# define CDK_AVAILABLE_IN_3_12                CDK_UNAVAILABLE(3, 12)
#else
# define CDK_AVAILABLE_IN_3_12                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_14
# define CDK_DEPRECATED_IN_3_14               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_14_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_14               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_14_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_14
# define CDK_AVAILABLE_IN_3_14                CDK_UNAVAILABLE(3, 14)
#else
# define CDK_AVAILABLE_IN_3_14                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_16
# define CDK_DEPRECATED_IN_3_16               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_16_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_16               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_16_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_16
# define CDK_AVAILABLE_IN_3_16                CDK_UNAVAILABLE(3, 16)
#else
# define CDK_AVAILABLE_IN_3_16                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_18
# define CDK_DEPRECATED_IN_3_18               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_18_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_18               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_18_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_18
# define CDK_AVAILABLE_IN_3_18                CDK_UNAVAILABLE(3, 18)
#else
# define CDK_AVAILABLE_IN_3_18                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_20
# define CDK_DEPRECATED_IN_3_20               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_20_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_20               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_20_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_20
# define CDK_AVAILABLE_IN_3_20                CDK_UNAVAILABLE(3, 20)
#else
# define CDK_AVAILABLE_IN_3_20                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_22
# define CDK_DEPRECATED_IN_3_22               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_22_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_22               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_22_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_22
# define CDK_AVAILABLE_IN_3_22                CDK_UNAVAILABLE(3, 22)
#else
# define CDK_AVAILABLE_IN_3_22                _CDK_EXTERN
#endif

#if CDK_VERSION_MIN_REQUIRED >= CDK_VERSION_3_24
# define CDK_DEPRECATED_IN_3_24               CDK_DEPRECATED
# define CDK_DEPRECATED_IN_3_24_FOR(f)        CDK_DEPRECATED_FOR(f)
#else
# define CDK_DEPRECATED_IN_3_24               _CDK_EXTERN
# define CDK_DEPRECATED_IN_3_24_FOR(f)        _CDK_EXTERN
#endif

#if CDK_VERSION_MAX_ALLOWED < CDK_VERSION_3_24
# define CDK_AVAILABLE_IN_3_24                CDK_UNAVAILABLE(3, 24)
#else
# define CDK_AVAILABLE_IN_3_24                _CDK_EXTERN
#endif

#endif  /* __CDK_VERSION_MACROS_H__ */


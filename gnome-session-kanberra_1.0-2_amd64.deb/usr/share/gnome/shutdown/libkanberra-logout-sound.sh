#!/bin/sh

/usr/bin/kanberra-ctk-play --id="desktop-logout" --description="GNOME Logout"

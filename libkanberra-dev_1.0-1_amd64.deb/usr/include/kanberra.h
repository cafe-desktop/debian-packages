/*-*- Mode: C; c-basic-offset: 8 -*-*/

#ifndef fookanberrahfoo
#define fookanberrahfoo

/***
  This file is part of libkanberra.

  Copyright 2008 Lennart Poettering

  libkanberra is free software; you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation, either version 2.1 of the
  License, or (at your option) any later version.

  libkanberra is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with libkanberra. If not, see
  <http://www.gnu.org/licenses/>.
***/

#include <sys/types.h>
#include <sys/param.h>
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

#define GNUC_UNUSED \
  __attribute__ ((__unused__))

#ifndef __GNUC__
/* Make sure __attribute__ works on non-gcc systems. Yes, might be a bit ugly */
#define __attribute__(x)
#endif

/**
 * KA_MAJOR:
 *
 * Evaluates to the major version number of libkanberra.
 */
#define KA_MAJOR (1)

/**
 * KA_MINOR:
 *
 * Evaluates to the minor version number of libkanberra.
 */
#define KA_MINOR (0)

/**
 * KA_CHECK_VERSION:
 *
 * Evaluates to TRUE when the library version is newer than the
 * specified parameters.
 */
#define KA_CHECK_VERSION(major,minor)                   \
        ((KA_MAJOR > (major)) ||                        \
         (KA_MAJOR == (major) && KA_MINOR >= (minor)))

/**
 * KA_PROP_MEDIA_NAME:
 *
 * A name describing the media being played. Localized if possible and applicable.
 */
#define KA_PROP_MEDIA_NAME                         "media.name"

/**
 * KA_PROP_MEDIA_TITLE:
 *
 * A (song) title describing the media being played. Localized if possible and applicable.
 */
#define KA_PROP_MEDIA_TITLE                        "media.title"

/**
 * KA_PROP_MEDIA_ARTIST:
 *
 * The artist of this media. Localized if possible and applicable.
 */
#define KA_PROP_MEDIA_ARTIST                       "media.artist"

/**
 * KA_PROP_MEDIA_LANGUAGE:
 *
 * The language this media is in, in some standard POSIX locale string, such as "de_DE".
 */
#define KA_PROP_MEDIA_LANGUAGE                     "media.language"

/**
 * KA_PROP_MEDIA_FILENAME:
 *
 * The file name this media was or can be loaded from.
 */
#define KA_PROP_MEDIA_FILENAME                     "media.filename"

/**
 * KA_PROP_MEDIA_ICON:
 *
 * An icon for this media in binary PNG format.
 */
#define KA_PROP_MEDIA_ICON                         "media.icon"

/**
 * KA_PROP_MEDIA_ICON_NAME:
 *
 * An icon name as defined in the XDG icon naming specifcation.
 */
#define KA_PROP_MEDIA_ICON_NAME                    "media.icon_name"

/**
 * KA_PROP_MEDIA_ROLE:
 *
 * The "role" this media is played in. For event sounds the string
 * "event". For other cases strings like "music", "video", "game", ...
 */
#define KA_PROP_MEDIA_ROLE                         "media.role"

/**
 * KA_PROP_EVENT_ID:
 *
 * A textual id for an event sound, as mandated by the XDG sound naming specification.
 */
#define KA_PROP_EVENT_ID                           "event.id"

/**
 * KA_PROP_EVENT_DESCRIPTION:
 *
 * A descriptive string for the sound event. Localized if possible and applicable.
 */
#define KA_PROP_EVENT_DESCRIPTION                  "event.description"

/**
 * KA_PROP_EVENT_MOUSE_X:
 *
 * If this sound event was triggered by a mouse input event, the X
 * position of the mouse cursor on the screen, formatted as string.
 */
#define KA_PROP_EVENT_MOUSE_X                      "event.mouse.x"

/**
 * KA_PROP_EVENT_MOUSE_Y:
 *
 * If this sound event was triggered by a mouse input event, the Y
 * position of the mouse cursor on the screen, formatted as string.
 */
#define KA_PROP_EVENT_MOUSE_Y                      "event.mouse.y"

/**
 * KA_PROP_EVENT_MOUSE_HPOS:
 *
 * If this sound event was triggered by a mouse input event, the X
 * position of the mouse cursor as fractional value between 0 and 1,
 * formatted as string, 0 reflecting the left side of the screen, 1
 * the right side.
 */
#define KA_PROP_EVENT_MOUSE_HPOS                   "event.mouse.hpos"

/**
 * KA_PROP_EVENT_MOUSE_VPOS:
 *
 * If this sound event was triggered by a mouse input event, the Y
 * position of the mouse cursor as fractional value between 0 and 1,
 * formatted as string, 0 reflecting the top end of the screen, 1
 * the bottom end.
 */
#define KA_PROP_EVENT_MOUSE_VPOS                   "event.mouse.vpos"

/**
 * KA_PROP_EVENT_MOUSE_BUTTON:
 *
 * If this sound event was triggered by a mouse input event, the
 * number of the mouse button that triggered it, formatted as string. 1
 * for left mouse button, 3 for right, 2 for middle.
 */
#define KA_PROP_EVENT_MOUSE_BUTTON                 "event.mouse.button"

/**
 * KA_PROP_WINDOW_NAME:
 *
 * If this sound event was triggered by a window on the screen, the
 * name of this window as human readable string.
 */
#define KA_PROP_WINDOW_NAME                        "window.name"

/**
 * KA_PROP_WINDOW_ID:
 *
 * If this sound event was triggered by a window on the screen, some
 * identification string for this window, so that the sound system can
 * recognize specific windows.
 */
#define KA_PROP_WINDOW_ID                          "window.id"

/**
 * KA_PROP_WINDOW_ICON:
 *
 * If this sound event was triggered by a window on the screen, binary
 * icon data in PNG format for this window.
 */
#define KA_PROP_WINDOW_ICON                        "window.icon"

/**
 * KA_PROP_WINDOW_ICON_NAME:
 *
 * If this sound event was triggered by a window on the screen, an
 * icon name for this window, as defined in the XDG icon naming
 * specification.
 */
#define KA_PROP_WINDOW_ICON_NAME                   "window.icon_name"

/**
 * KA_PROP_WINDOW_X:
 *
 * If this sound event was triggered by a window on the screen, the X
 * position of the window measured from the top left corner of the
 * screen to the top left corner of the window.
 *
 * Since: 0.17
 */
#define KA_PROP_WINDOW_X                           "window.x"

/**
 * KA_PROP_WINDOW_Y:
 *
 * If this sound event was triggered by a window on the screen, the y
 * position of the window measured from the top left corner of the
 * screen to the top left corner of the window.
 *
 * Since: 0.17
 */
#define KA_PROP_WINDOW_Y                           "window.y"

/**
 * KA_PROP_WINDOW_WIDTH:
 *
 * If this sound event was triggered by a window on the screen, the
 * pixel width of the window.
 *
 * Since: 0.17
 */
#define KA_PROP_WINDOW_WIDTH                       "window.width"

/**
 * KA_PROP_WINDOW_HEIGHT:
 *
 * If this sound event was triggered by a window on the screen, the
 * pixel height of the window.
 *
 * Since: 0.17
 */
#define KA_PROP_WINDOW_HEIGHT                      "window.height"

/**
 * KA_PROP_WINDOW_HPOS:
 *
 * If this sound event was triggered by a window on the screen, the X
 * position of the center of the window as fractional value between 0
 * and 1, formatted as string, 0 reflecting the left side of the
 * screen, 1 the right side.
 *
 * Since: 0.17
 */
#define KA_PROP_WINDOW_HPOS                        "window.hpos"

/**
 * KA_PROP_WINDOW_VPOS:
 *
 * If this sound event was triggered by a window on the screen, the Y
 * position of the center of the window as fractional value between 0
 * and 1, formatted as string, 0 reflecting the top side of the
 * screen, 1 the bottom side.
 *
 * Since: 0.17
 */
#define KA_PROP_WINDOW_VPOS                        "window.vpos"

/**
 * KA_PROP_WINDOW_DESKTOP:
 *
 * If this sound event was triggered by a window on the screen and the
 * windowing system supports multiple desktops, a comma seperated list
 * of indexes of the desktops this window is visible on. If this
 * property is an empty string, it is visible on all desktops
 * (i.e. 'sticky'). The first desktop is 0. (e.g. "0,2,3")
 *
 * Since: 0.18
 */
#define KA_PROP_WINDOW_DESKTOP                    "window.desktop"

/**
 * KA_PROP_WINDOW_X11_DISPLAY:
 *
 * If this sound event was triggered by a window on the screen and the
 * windowing system is X11, the X display name of the window (e.g. ":0").
 */
#define KA_PROP_WINDOW_X11_DISPLAY                 "window.x11.display"

/**
 * KA_PROP_WINDOW_X11_SCREEN:
 *
 * If this sound event was triggered by a window on the screen and the
 * windowing system is X11, the X screen id of the window formatted as
 * string (e.g. "0").
 */
#define KA_PROP_WINDOW_X11_SCREEN                  "window.x11.screen"

/**
 * KA_PROP_WINDOW_X11_MONITOR:
 *
 * If this sound event was triggered by a window on the screen and the
 * windowing system is X11, the X monitor id of the window formatted as
 * string (e.g. "0").
 */
#define KA_PROP_WINDOW_X11_MONITOR                 "window.x11.monitor"

/**
 * KA_PROP_WINDOW_X11_XID:
 *
 * If this sound event was triggered by a window on the screen and the
 * windowing system is X11, the XID of the window formatted as string.
 */
#define KA_PROP_WINDOW_X11_XID                     "window.x11.xid"

/**
 * KA_PROP_APPLICATION_NAME:
 *
 * The name of the application this sound event was triggered by as
 * human readable string. (e.g. "GNU Emacs") Localized if possible and
 * applicable.
 */
#define KA_PROP_APPLICATION_NAME                   "application.name"

/**
 * KA_PROP_APPLICATION_ID:
 *
 * An identifier for the program this sound event was triggered
 * by. (e.g. "org.gnu.emacs").
 */
#define KA_PROP_APPLICATION_ID                     "application.id"

/**
 * KA_PROP_APPLICATION_VERSION:
 *
 * A version number for the program this sound event was triggered
 * by. (e.g. "22.2")
 */
#define KA_PROP_APPLICATION_VERSION                "application.version"

/**
 * KA_PROP_APPLICATION_ICON:
 *
 * Binary icon data in PNG format for the application this sound event
 * is triggered by.
 */
#define KA_PROP_APPLICATION_ICON                   "application.icon"

/**
 * KA_PROP_APPLICATION_ICON_NAME:
 *
 * An icon name for the application this sound event is triggered by,
 * as defined in the XDG icon naming specification.
 */
#define KA_PROP_APPLICATION_ICON_NAME              "application.icon_name"

/**
 * KA_PROP_APPLICATION_LANGUAGE:
 *
 * The locale string the application that is triggering this sound
 * event is running in. A POSIX locale string such as de_DE@euro.
 */
#define KA_PROP_APPLICATION_LANGUAGE               "application.language"

/**
 * KA_PROP_APPLICATION_PROCESS_ID:
 *
 * The unix PID of the process that is triggering this sound event, formatted as string.
 */
#define KA_PROP_APPLICATION_PROCESS_ID             "application.process.id"

/**
 * KA_PROP_APPLICATION_PROCESS_BINARY:
 *
 * The path to the process binary of the process that is triggering this sound event.
 */
#define KA_PROP_APPLICATION_PROCESS_BINARY         "application.process.binary"

/**
 * KA_PROP_APPLICATION_PROCESS_USER:
 *
 * The user that owns the process that is triggering this sound event.
 */
#define KA_PROP_APPLICATION_PROCESS_USER           "application.process.user"

/**
 * KA_PROP_APPLICATION_PROCESS_HOST:
 *
 * The host name of the host the process that is triggering this sound event runs on.
 */
#define KA_PROP_APPLICATION_PROCESS_HOST           "application.process.host"

/**
 * KA_PROP_KANBERRA_CACHE_CONTROL:
 *
 * A special property that can be used to control the automatic sound
 * caching of sounds in the sound server. One of "permanent",
 * "volatile", "never". "permanent" will cause this sample to be
 * cached in the server permanently. This is useful for very
 * frequently used sound events such as those used for input
 * feedback. "volatile" may be used for cacheing sounds in the sound
 * server temporarily. They will expire after some time or on cache
 * pressure. Finally, "never" may be used for sounds that should never
 * be cached, because they are only generated very seldomly or even
 * only once at most (such as desktop login sounds).
 *
 * If this property is not explicitly passed to ka_context_play() it
 * will default to "never". If it is not explicitly passed to
 * ka_context_cache() it will default to "permanent".
 *
 * If the list of properties is handed on to the sound server this
 * property is stripped from it.
 */
#define KA_PROP_KANBERRA_CACHE_CONTROL             "kanberra.cache-control"

/**
 * KA_PROP_KANBERRA_VOLUME:
 *
 * A special property that can be used to control the volume this
 * sound event is played in if the backend supports it. A floating
 * point value for the decibel multiplier for the sound. 0 dB relates
 * to zero gain, and is the default volume these sounds are played in.
 *
 * If the list of properties is handed on to the sound server this
 * property is stripped from it.
 */
#define KA_PROP_KANBERRA_VOLUME                    "kanberra.volume"

/**
 * KA_PROP_KANBERRA_XDG_THEME_NAME:
 *
 * A special property that can be used to control the XDG sound theme that
 * is used for this sample.
 *
 * If the list of properties is handed on to the sound server this
 * property is stripped from it.
 */
#define KA_PROP_KANBERRA_XDG_THEME_NAME            "kanberra.xdg-theme.name"

/**
 * KA_PROP_KANBERRA_XDG_THEME_OUTPUT_PROFILE:
 *
 * A special property that can be used to control the XDG sound theme
 * output profile that is used for this sample.
 *
 * If the list of properties is handed on to the sound server this
 * property is stripped from it.
 */
#define KA_PROP_KANBERRA_XDG_THEME_OUTPUT_PROFILE  "kanberra.xdg-theme.output-profile"

/**
 * KA_PROP_KANBERRA_ENABLE:
 *
 * A special property that can be used to control whether any sounds
 * are played at all. If this property is "1" or unset sounds are
 * played as normal. However, if it is "0" all calls to
 * ka_context_play() will fail with KA_ERROR_DISABLED.
 *
 * If the list of properties is handed on to the sound server this
 * property is stripped from it.
 */
#define KA_PROP_KANBERRA_ENABLE                    "kanberra.enable"

/**
 * KA_PROP_KANBERRA_FORCE_CHANNEL:
 *
 * A special property that can be used to control on which channel a
 * sound is played. The value should be one of mono, front-left,
 * front-right, front-center, rear-left, rear-right, rear-center, lfe,
 * front-left-of-center, front-right-of-center, side-left, side-right,
 * top-center, top-front-left, top-front-right, top-front-center,
 * top-rear-left, top-rear-right, top-rear-center. This property is
 * only honoured by some backends, other backends may choose to ignore
 * it completely.
 *
 * If the list of properties is handed on to the sound server this
 * property is stripped from it.
 *
 * Since: 0.13
 */
#define KA_PROP_KANBERRA_FORCE_CHANNEL             "kanberra.force_channel"

/**
 * ka_context:
 *
 * A libkanberra context object.
 */
typedef struct ka_context ka_context;

/**
 * ka_finish_callback_t:
 * @c: The libkanberra context this callback is called for
 * @id: The numerical id passed to the ka_context_play_full() when starting the event sound playback.
 * @error_code: A numerical error code describing the reason this callback is called. If KA_SUCCESS is passed in the playback of the event sound was successfully completed.
 * @userdata: Some arbitrary user data the caller of ka_context_play_full() passed in.
 *
 * Playback completion event callback. The context this callback is
 * called in is undefined, it might or might not be called from a
 * background thread, and from any stack frame. The code implementing
 * this function may not call any libkanberra API call from this
 * callback -- this might result in a deadlock. Instead it may only be
 * used to asynchronously signal some kind of notification object
 * (semaphore, message queue, ...).
 */
typedef void (*ka_finish_callback_t)(ka_context *c, uint32_t id, int error_code, void *userdata);

/**
 * Error codes:
 * @KA_SUCCESS: Success
 *
 * Error codes
 */
enum {
        KA_SUCCESS = 0,
        KA_ERROR_NOTSUPPORTED = -1,
        KA_ERROR_INVALID = -2,
        KA_ERROR_STATE = -3,
        KA_ERROR_OOM = -4,
        KA_ERROR_NODRIVER = -5,
        KA_ERROR_SYSTEM = -6,
        KA_ERROR_CORRUPT = -7,
        KA_ERROR_TOOBIG = -8,
        KA_ERROR_NOTFOUND = -9,
        KA_ERROR_DESTROYED = -10,
        KA_ERROR_CANCELED = -11,
        KA_ERROR_NOTAVAILABLE = -12,
        KA_ERROR_ACCESS = -13,
        KA_ERROR_IO = -14,
        KA_ERROR_INTERNAL = -15,
        KA_ERROR_DISABLED = -16,
        KA_ERROR_FORKED = -17,
        KA_ERROR_DISCONNECTED = -18,
        _KA_ERROR_MAX = -19
};

/**
 * ka_proplist:
 *
 * A kanberra property list object. Basically a hashtable.
 */
typedef struct ka_proplist ka_proplist;

int ka_proplist_create(ka_proplist **p);
int ka_proplist_destroy(ka_proplist *p);
int ka_proplist_sets(ka_proplist *p, const char *key, const char *value);
int ka_proplist_setf(ka_proplist *p, const char *key, const char *format, ...) __attribute__((format(printf, 3, 4)));
int ka_proplist_set(ka_proplist *p, const char *key, const void *data, size_t nbytes);

int ka_context_create(ka_context **c);
int ka_context_set_driver(ka_context *c, const char *driver);
int ka_context_change_device(ka_context *c, const char *device);
int ka_context_open(ka_context *c);
int ka_context_destroy(ka_context *c);
int ka_context_change_props(ka_context *c, ...) __attribute__((sentinel));
int ka_context_change_props_full(ka_context *c, ka_proplist *p);
int ka_context_play_full(ka_context *c, uint32_t id, ka_proplist *p, ka_finish_callback_t cb, void *userdata);
int ka_context_play(ka_context *c, uint32_t id, ...) __attribute__((sentinel));
int ka_context_cache_full(ka_context *c, ka_proplist *p);
int ka_context_cache(ka_context *c, ...) __attribute__((sentinel));
int ka_context_cancel(ka_context *c, uint32_t id);
int ka_context_playing(ka_context *c, uint32_t id, int *playing);

const char *ka_strerror(int code);

#ifdef __cplusplus
}
#endif

#endif
